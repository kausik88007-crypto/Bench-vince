#!/bin/bash
git init -q 2>/dev/null
git add README.md && git commit -qm "Add README and project structure"
for f in drawings/*; do git add "$f"; git commit -qm "Added $(basename "$f")"; done
git add 3d-models && git commit -qm "Added 3D models"
git add exports-pdf && git commit -qm "Added PDF exports"
git add renders && git commit -qm "Added renders"
