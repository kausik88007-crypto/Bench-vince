# Bench Vice – 3D Assembly, Exploded View & Drawings

![Assembled](renders/vice_assembled.png)
![Exploded](renders/vice_exploded.png)
![Assembly drawing](renders/vice_assembly_drawing.png)
![Parts](renders/vice_part_drawings.png)

## Folders
`/drawings` (2D DXF) · `/3d-models` (DXF + STL: parts, assembly, exploded) · `/exports-pdf` · `/renders`

## Parts / BOM
Base, fixed jaw, moving jaw, screw, handle, 2 guide rods (see BOM table in the assembly drawing).

## AutoCAD version / tools
AutoCAD 2024. EXTRUDE, REVOLVE, UNION/SUBTRACT, 3DMOVE/3DROTATE, SECTIONPLANE, FLATSHOT, TABLE, LAYOUT.

## 3D viewing in AutoCAD
Open `3d-models/vice_assembly.dxf` → `VSCURRENT` Realistic → `3DORBIT`. Use `CONVTOSOLID` on the mesh parts, then SUBTRACT holes/threads, `SECTIONPLANE` + `FLATSHOT` for views, and `RENDER`.

## What I learned
(Fill in.)
